package ipa.dto;

public class EmployeeDto {
    private String name;
    private String department;
    private String temperature;
    private String imagePath;

    public EmployeeDto(String name, String department, String temperature, String imagePath) {
        this.name = name;
        this.department = department;
        this.temperature = temperature;
        this.imagePath = imagePath;
    }

    public EmployeeDto() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String toCSVString() {
        return name + "," + department + "," + temperature + "," + imagePath;
    }
}
