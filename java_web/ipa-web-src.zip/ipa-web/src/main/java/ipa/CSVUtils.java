package ipa;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

import java.io.FileReader;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.*;

public class CSVUtils {
    public static final String KEY_NAME = "Name";
    public static final String KEY_TIME = "Time";
    public static final String KEY_TEMPERATURE = "Temperature";
    public static final String LOGIN_CSV_FILE = "image_login.csv";

    public static final String TEMPERATURE_CSV_FILE = "alert_bk.csv";

    public static final String BLACK_LIST_CSV_FILE = "blacklist.csv";

    public static final long ORIGINAL_TIME = 99999L;
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static Map<String, String> getLatestLoginEmployee() throws Exception {
        Map<String, String> map = new HashMap<>();

        Reader in = new FileReader(LOGIN_CSV_FILE);
        Iterable<CSVRecord> records = CSVFormat.DEFAULT.withFirstRecordAsHeader().
                withHeader("Name", "Time").parse(in);

        String currentName = "";
        long timeStamp = 0;
        long currentTime = System.currentTimeMillis()/1000;
        for (CSVRecord record : records) {
            String name = record.get(KEY_NAME);
            long loginTime = Long.parseLong(record.get(KEY_TIME));

            if(loginTime != ORIGINAL_TIME && loginTime >= (currentTime - 120) && loginTime > timeStamp ) {
                currentName = name;
                timeStamp = loginTime*1000;
            }
        }

        map.put(KEY_NAME, currentName);
        String timeStr = timeStamp != 0 ? DATE_FORMAT.format( new Date(timeStamp) ) : "";
        map.put(KEY_TIME, timeStr);

        String temperature = getTemperatureByName(currentName);
        map.put(KEY_TEMPERATURE, temperature);

        System.out.println("latest value from " + LOGIN_CSV_FILE + " and " + TEMPERATURE_CSV_FILE+ ",employee:" + currentName + ",time:" + timeStr + ",temperature:" + temperature);
        return map;
    }

    public static String getTemperatureByName(String name) throws Exception {
        Reader in = new FileReader(TEMPERATURE_CSV_FILE);
        Iterable<CSVRecord> records = CSVFormat.DEFAULT.withFirstRecordAsHeader().
                withHeader("Name", "Alert", "Temperature").parse(in);

        for (CSVRecord record : records) {
            if( record.get(KEY_NAME).trim().equalsIgnoreCase(name.trim()) ) {
                return record.get(KEY_TEMPERATURE).trim();
            }
        }
        return "";
    }

    public static Set<String> getBlackList() throws Exception {
        Set<String> set = new HashSet<>();
        Reader in = new FileReader(BLACK_LIST_CSV_FILE);
        Iterable<CSVRecord> records = CSVFormat.DEFAULT.withFirstRecordAsHeader().
                withHeader("Name", "Blacklisted").parse(in);

        for (CSVRecord record : records) {
            set.add(record.get(KEY_NAME).trim());
        }
        return set;
    }
}
