package phq;

import com.phqtime.phqtimetable.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import phq.dto.MatchResultDto;
import phq.dto.MatchResultSummaryDto;
import phq.dto.PatientDto;
import phq.dto.PractitionerDto;

import java.util.ArrayList;
import java.util.List;

@Service
public class MatchingService {

    private static Logger log = LoggerFactory.getLogger(MatchingService.class);

    @Autowired
    private PatientService patientService;

    MatchResultSummaryDto latestResult;

    public MatchResultSummaryDto matching() throws Exception {
        List<PatientDto> patientList = patientService.getAllPatients();
        List<PractitionerDto> practitionerList = patientService.getAllPractioners();

        PhqSessionScheduleSolution solution = PhqSessionScheduleApp.startMatching(patientList, practitionerList);
        PhqSessionScheduleApp.displayResult(solution);

        MatchResultSummaryDto resultDto = convertSolution(solution);

        latestResult = resultDto;

        return resultDto;
    }

    public MatchResultSummaryDto getLatestResult() throws Exception {
        return latestResult;
    }

    public MatchResultSummaryDto convertSolution(PhqSessionScheduleSolution solution) {

        StringBuilder totalScoreBuilder = new StringBuilder();
        totalScoreBuilder.append("Total score: ").append(solution.getScore().toString());

        List<MatchResultDto> matchedList = new ArrayList<>();

        List<PhqProcess> processList = solution.getPhqProcessList();
        //long processIndex = 0;

        for (PhqProcess process : processList) {
            /*StringBuilder processBuilder = new StringBuilder();
            processBuilder.append(processIndex).append(" -> ").append(process.getDesc());
            processIndex++;*/

            MatchResultDto dto = new MatchResultDto(process);
            matchedList.add( dto );
        }

        MatchResultSummaryDto summaryDto = new MatchResultSummaryDto(
                totalScoreBuilder.toString(), matchedList
        );

        return summaryDto;
    }
}

