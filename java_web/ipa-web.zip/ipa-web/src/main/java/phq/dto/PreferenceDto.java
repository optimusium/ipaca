package phq.dto;

public class PreferenceDto {

    private int practitionerRole = 0;
    private int language = 0;
    private int practitionerGender = 0;
    private int institutionLocation = 0;
    private int sessionDay = 0;

    public int getPractitionerRole() {
        return practitionerRole;
    }

    public String getPractitionerRoleStrValue() {
        String result;
        switch (practitionerRole) {
            case 0:
                result = "Psychologist";
                break;
            case 1:
                result = "Psychiatrist";
                break;
            default:
                result = "unknown";
                break;
        }
        return result;
    }

    public void setPractitionerRole(int practitionerRole) {
        this.practitionerRole = practitionerRole;
    }

    public int getLanguage() {
        return language;
    }

    public String getLanguageStrValue() {
        String result;
        switch (language) {
            case 0:
                result = "No preference";
                break;
            case 1:
                result = "English";
                break;
            case 2:
                result = "Chinese";
                break;
            case 3:
                result = "Malay";
                break;
            case 4:
                result = "Tamil";
                break;
            default:
                result = "unknown";
                break;
        }
        return result;
    }

    public void setLanguage(int language) {
        this.language = language;
    }

    public int getPractitionerGender() {
        return practitionerGender;
    }

    public String getPractitionerGenderStrValue() {
        String result;
        switch (practitionerGender) {
            case 0:
                result = "Male";
                break;
            case 1:
                result = "Female";
                break;
            default:
                result = "unknown";
                break;
        }
        return result;
    }

    public void setPractitionerGender(int practitionerGender) {
        this.practitionerGender = practitionerGender;
    }

    public int getInstitutionLocation() {
        return institutionLocation;
    }

    public String getInstitutionLocationStrValue() {
        String result;
        switch (institutionLocation) {
            case 0:
                result = "Central";
                break;
            case 1:
                result = "North";
                break;
            case 2:
                result = "East";
                break;
            case 3:
                result = "West";
                break;
            case 4:
                result = "Northeast";
                break;
            default:
                result = "unknown";
                break;
        }
        return result;
    }

    public void setInstitutionLocation(int institutionLocation) {
        this.institutionLocation = institutionLocation;
    }

    public int getSessionDay() {
        return sessionDay;
    }

    public String getSessionDayStrValue() {
        String result = "";
        switch (sessionDay) {
            case 0:
                result = "Monday";
                break;
            case 1:
                result = "Tuesday";
                break;
            case 2:
                result = "Wednesday";
                break;
            case 3:
                result = "Thursday";
                break;
            case 4:
                result = "Friday";
                break;
            case 5:
                result = "Saturday";
                break;
            case 6:
                result = "Sunday";
                break;
            default:
                result = "unknown";
                break;
        }
        return result;
    }

    public void setSessionDay(int sessionDay) {
        this.sessionDay = sessionDay;
    }
}